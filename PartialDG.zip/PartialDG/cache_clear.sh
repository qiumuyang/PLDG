#!/bin/bash

# remove shared memory dataset cache

rm -r /dev/shm/sharearray_Abdomen*.npy
rm -r /dev/shm/sharearray_Abdomen*.npy.lock
